import Image from "next/image"

interface WeatherCardProps {
  city: string
  country: string
  date: string
  temperature: number
  description: string
  icon: string
  isCelsius: boolean
}

export default function WeatherCard({
  city,
  country,
  date,
  temperature,
  description,
  icon,
  isCelsius,
}: WeatherCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="p-6 md:p-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">
              {city}, {country}
            </h1>
            <p className="text-gray-500 mt-1">{date}</p>
          </div>
          <div className="flex items-center mt-4 md:mt-0">
            <Image src={`https://openweathermap.org/img/wn/${icon}@2x.png`} alt={description} width={80} height={80} />
            <div className="ml-2">
              <p className="text-5xl font-bold text-gray-800">
                {Math.round(temperature)}°{isCelsius ? "C" : "F"}
              </p>
              <p className="text-gray-600 capitalize">{description}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
