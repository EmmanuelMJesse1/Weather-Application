import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

interface TemperatureToggleProps {
  isCelsius: boolean
  onChange: () => void
}

export default function TemperatureToggle({ isCelsius, onChange }: TemperatureToggleProps) {
  return (
    <div className="flex items-center space-x-4">
      <Label htmlFor="temp-toggle" className={isCelsius ? "font-bold" : ""}>
        °C
      </Label>
      <Switch id="temp-toggle" checked={!isCelsius} onCheckedChange={onChange} />
      <Label htmlFor="temp-toggle" className={!isCelsius ? "font-bold" : ""}>
        °F
      </Label>
    </div>
  )
}
