import Image from "next/image"

interface ForecastCardProps {
  date: string
  temperature: number
  description: string
  icon: string
  isCelsius: boolean
}

export default function ForecastCard({ date, temperature, description, icon, isCelsius }: ForecastCardProps) {
  // Extract just the day name from the full date
  const dayName = date.split(",")[0]

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="p-4 text-center">
        <h3 className="font-bold text-lg text-gray-800">{dayName}</h3>
        <div className="flex justify-center my-2">
          <Image src={`https://openweathermap.org/img/wn/${icon}@2x.png`} alt={description} width={60} height={60} />
        </div>
        <p className="text-2xl font-bold text-gray-800">
          {Math.round(temperature)}°{isCelsius ? "C" : "F"}
        </p>
        <p className="text-gray-600 text-sm capitalize">{description}</p>
      </div>
    </div>
  )
}
