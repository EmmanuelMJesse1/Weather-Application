import type { ReactNode } from "react"

interface InfoCardProps {
  title: string
  value: string
  icon: ReactNode
  description: string
}

export default function InfoCard({ title, value, icon, description }: InfoCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden p-6">
      <div className="flex items-center">
        <div className="mr-4">{icon}</div>
        <div>
          <h3 className="text-lg font-medium text-gray-700">{title}</h3>
          <p className="text-3xl font-bold text-gray-800 mt-1">{value}</p>
          <p className="text-gray-500 text-sm mt-1">{description}</p>
        </div>
      </div>
    </div>
  )
}
