import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const city = searchParams.get("city")

  if (!city) {
    return NextResponse.json({ error: "City parameter is required" }, { status: 400 })
  }

  try {
    // For development/testing, we can use a mock response if the backend is not available
    if (!process.env.BACKEND_URL) {
      console.warn("BACKEND_URL is not defined, using mock data")
      return NextResponse.json(getMockWeatherData(city))
    }

    // Proxy the request to our Laravel backend
    const response = await fetch(`${process.env.BACKEND_URL}/api/weather?city=${encodeURIComponent(city)}`, {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })

    // Check if the response is JSON
    const contentType = response.headers.get("content-type")
    if (!contentType || !contentType.includes("application/json")) {
      console.error("Invalid response format:", await response.text())
      return NextResponse.json({ error: "Invalid response from weather service" }, { status: 500 })
    }

    if (!response.ok) {
      const errorData = await response.json()
      return NextResponse.json(
        { error: errorData.message || "Failed to fetch weather data" },
        { status: response.status },
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error fetching weather data:", error)

    // Fallback to mock data in case of error (for demo purposes)
    console.warn("Using mock data due to API error")
    return NextResponse.json(getMockWeatherData(city))
  }
}

// Mock data function for development/testing
function getMockWeatherData(city: string) {
  return {
    coord: { lon: -0.1257, lat: 51.5085 },
    weather: [
      {
        id: 800,
        main: "Clear",
        description: "clear sky",
        icon: "01d",
      },
    ],
    base: "stations",
    main: {
      temp: 18.5,
      feels_like: 18.2,
      temp_min: 16.89,
      temp_max: 19.85,
      pressure: 1016,
      humidity: 72,
    },
    visibility: 10000,
    wind: {
      speed: 4.12,
      deg: 250,
    },
    clouds: {
      all: 0,
    },
    dt: 1619432400,
    sys: {
      type: 2,
      id: 2019646,
      country: "GB",
      sunrise: 1619413751,
      sunset: 1619464870,
    },
    timezone: 3600,
    id: 2643743,
    name: city || "London",
    cod: 200,
  }
}
