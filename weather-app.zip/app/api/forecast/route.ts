import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const city = searchParams.get("city")

  if (!city) {
    return NextResponse.json({ error: "City parameter is required" }, { status: 400 })
  }

  try {
    // For development/testing, we can use a mock response if the backend is not available
    if (!process.env.BACKEND_URL) {
      console.warn("BACKEND_URL is not defined, using mock data")
      return NextResponse.json(getMockForecastData(city))
    }

    // Proxy the request to our Laravel backend
    const response = await fetch(`${process.env.BACKEND_URL}/api/forecast?city=${encodeURIComponent(city)}`, {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })

    // Check if the response is JSON
    const contentType = response.headers.get("content-type")
    if (!contentType || !contentType.includes("application/json")) {
      console.error("Invalid response format:", await response.text())
      return NextResponse.json({ error: "Invalid response from forecast service" }, { status: 500 })
    }

    if (!response.ok) {
      const errorData = await response.json()
      return NextResponse.json(
        { error: errorData.message || "Failed to fetch forecast data" },
        { status: response.status },
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error fetching forecast data:", error)

    // Fallback to mock data in case of error (for demo purposes)
    console.warn("Using mock data due to API error")
    return NextResponse.json(getMockForecastData(city))
  }
}

// Mock data function for development/testing
function getMockForecastData(city: string) {
  const baseTimestamp = Math.floor(Date.now() / 1000)
  const dayInSeconds = 86400

  return [
    {
      dt: baseTimestamp,
      main: {
        temp: 18.5,
        feels_like: 18.2,
        temp_min: 16.89,
        temp_max: 19.85,
        pressure: 1016,
        humidity: 72,
      },
      weather: [
        {
          id: 800,
          main: "Clear",
          description: "clear sky",
          icon: "01d",
        },
      ],
      clouds: {
        all: 0,
      },
      wind: {
        speed: 4.12,
        deg: 250,
      },
      dt_txt: "2023-04-26 12:00:00",
    },
    {
      dt: baseTimestamp + dayInSeconds,
      main: {
        temp: 17.2,
        feels_like: 16.8,
        temp_min: 15.5,
        temp_max: 18.3,
        pressure: 1014,
        humidity: 68,
      },
      weather: [
        {
          id: 801,
          main: "Clouds",
          description: "few clouds",
          icon: "02d",
        },
      ],
      clouds: {
        all: 20,
      },
      wind: {
        speed: 3.8,
        deg: 240,
      },
      dt_txt: "2023-04-27 12:00:00",
    },
    {
      dt: baseTimestamp + dayInSeconds * 2,
      main: {
        temp: 19.8,
        feels_like: 19.5,
        temp_min: 18.2,
        temp_max: 21.4,
        pressure: 1012,
        humidity: 65,
      },
      weather: [
        {
          id: 500,
          main: "Rain",
          description: "light rain",
          icon: "10d",
        },
      ],
      clouds: {
        all: 40,
      },
      wind: {
        speed: 5.2,
        deg: 220,
      },
      dt_txt: "2023-04-28 12:00:00",
    },
  ]
}
