"use client"

import { useState, useEffect } from "react"
import { Wind, Droplets } from "lucide-react"
import WeatherCard from "@/components/weather-card"
import ForecastCard from "@/components/forecast-card"
import SearchBar from "@/components/search-bar"
import TemperatureToggle from "@/components/temperature-toggle"
import InfoCard from "@/components/info-card"
import { Button } from "@/components/ui/button"

export default function Home() {
  const [city, setCity] = useState<string>("London")
  const [weather, setWeather] = useState<any>(null)
  const [forecast, setForecast] = useState<any[]>([])
  const [isCelsius, setIsCelsius] = useState<boolean>(true)
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)

  // Fetch weather data when city changes
  useEffect(() => {
    const fetchWeatherData = async () => {
      try {
        setLoading(true)
        setError(null)

        // Fetch current weather
        const weatherResponse = await fetch(`/api/weather?city=${encodeURIComponent(city)}`)

        if (!weatherResponse.ok) {
          const errorData = await weatherResponse.json().catch(() => ({ error: "Failed to parse response" }))
          throw new Error(errorData.error || "Failed to fetch weather data")
        }

        const weatherData = await weatherResponse.json()

        // Fetch forecast
        const forecastResponse = await fetch(`/api/forecast?city=${encodeURIComponent(city)}`)

        if (!forecastResponse.ok) {
          const errorData = await forecastResponse.json().catch(() => ({ error: "Failed to parse response" }))
          throw new Error(errorData.error || "Failed to fetch forecast data")
        }

        const forecastData = await forecastResponse.json()

        setWeather(weatherData)
        setForecast(Array.isArray(forecastData) ? forecastData.slice(0, 3) : []) // Get next 3 days
      } catch (err: any) {
        setError(`Error: ${err.message || "Something went wrong"}`)
        console.error("Error fetching data:", err)
      } finally {
        setLoading(false)
      }
    }

    if (city) {
      fetchWeatherData()
    }
  }, [city])

  // Convert temperature based on selected unit
  const convertTemp = (temp: number): number => {
    if (isCelsius) {
      return temp
    }
    return (temp * 9) / 5 + 32
  }

  // Format date
  const formatDate = (timestamp: number): string => {
    return new Date(timestamp * 1000).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-sky-100 to-blue-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
          <SearchBar onSearch={setCity} />
          <TemperatureToggle isCelsius={isCelsius} onChange={() => setIsCelsius(!isCelsius)} />
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6 flex flex-col">
            <p>{error}</p>
            <Button variant="outline" className="mt-2 self-start" onClick={() => setCity("London")}>
              Try with default city (London)
            </Button>
          </div>
        )}

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          weather && (
            <>
              {/* Main Weather Card */}
              <WeatherCard
                city={weather.name}
                country={weather.sys.country}
                date={formatDate(weather.dt)}
                temperature={convertTemp(weather.main.temp)}
                description={weather.weather[0].description}
                icon={weather.weather[0].icon}
                isCelsius={isCelsius}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                {/* Weather Info Cards */}
                <InfoCard
                  title="Wind Status"
                  value={`${weather.wind.speed} m/s`}
                  icon={<Wind className="h-8 w-8 text-blue-500" />}
                  description={`Direction: ${weather.wind.deg}°`}
                />
                <InfoCard
                  title="Humidity"
                  value={`${weather.main.humidity}%`}
                  icon={<Droplets className="h-8 w-8 text-blue-500" />}
                  description="Relative humidity"
                />
              </div>

              {/* Forecast Section */}
              {forecast.length > 0 && (
                <>
                  <h2 className="text-2xl font-bold mt-10 mb-6">3-Day Forecast</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    {forecast.map((day, index) => (
                      <ForecastCard
                        key={index}
                        date={formatDate(day.dt)}
                        temperature={convertTemp(day.main.temp)}
                        description={day.weather[0].description}
                        icon={day.weather[0].icon}
                        isCelsius={isCelsius}
                      />
                    ))}
                  </div>
                </>
              )}
            </>
          )
        )}
      </div>
    </main>
  )
}
